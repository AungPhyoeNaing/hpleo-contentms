from django.apps import AppConfig


class ImporterConfig(AppConfig):
    name = 'apps.importer'
